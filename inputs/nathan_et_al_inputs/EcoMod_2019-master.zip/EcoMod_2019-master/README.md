# EcoMod_2019
Input files, outputs, and R scripts for running Bull Trout-Dolly Varden simulations in CDMetaPOP

Reference: Nathan, L.R. et al. 2019. A spatially-explicit, individual-based demogenetic simulation 
framework for evaluating hybridization dynamics. Ecological Modelling ##.
